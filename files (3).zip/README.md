# Simple Chat Bot (Node + Express)

Minimal chat bot demo that forwards messages to the OpenAI Chat Completions API.

Setup
1. Copy the files into a folder.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set `OPENAI_API_KEY`.
4. `npm start`
5. Open `http://localhost:3000`

Notes & next steps
- This demo keeps the API key on the server; never expose it to the browser.
- For production: add proper authentication, persistent session storage, request validation, and better rate-limiting.
- To answer from your documents: build an embeddings pipeline + vector DB and prepend retrieved docs to the messages.
- Want integration with Telegram/Discord/Slack or a Python version? Ask and I'll provide it.